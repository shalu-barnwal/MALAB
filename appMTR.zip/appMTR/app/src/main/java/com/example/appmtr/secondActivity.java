package com.example.appmtr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class secondActivity extends AppCompatActivity {
    Button veg, nonVeg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        veg = findViewById(R.id.veg);
        nonVeg = findViewById(R.id.nVeg);

        veg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(true){
                    Toast.makeText(MainActivity.this, "Veg Button has been clicked", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, thirdActivity.class);
                    MainActivity.this.startActivity(intent);
                } else{
                    Toast.makeText(MainActivity.this, "Oops SORRY!!!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        nonVeg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(true){
                    Toast.makeText(MainActivity.this, "Non Veg Button has been clicked", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, fourthActivity.class);
                    MainActivity.this.startActivity(intent);
                } else{
                    Toast.makeText(MainActivity.this, "Oops SORRY!!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}